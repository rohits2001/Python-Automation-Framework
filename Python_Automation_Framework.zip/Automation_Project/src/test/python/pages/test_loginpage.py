import sys
import os
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from base.basetest import BaseTest

#class LoginPage(BaseTest):
    
class LoginPage:
    # LoginPage class implementation
     pass
    

     def __init__(self, driver):
        """Initialize LoginPage with driver."""
        self.driver = driver
        self.wait = WebDriverWait(driver, 10)  # Explicit wait for elements
        
        # Define the locators for the elements
        self.loc = {
            'link_SignInUsingOtp': "//*[text()='Sign in using otp?']",  # Example XPath, update with correct locator
            'txt_phoneOrEmail': "//input[@formcontrolname='email']",
            'btn_GetOTP': "//*[text()='Get OTP']",
            'otp_field_xpath': "otp_0_0u4nb91antvflztrkqy3",
            'btn_Login': "//*[text()='Login']"}
        
    # Method to click on the "Sign In using OTP" link
     def click_on_link_sign_in_using_otp(self):
        sign_in_link = self.wait.until(EC.visibility_of_element_located((By.XPATH, self.loc.get('link_SignInUsingOtp'))))
        sign_in_link.click()

    # Method to enter phone number or email address
     def enter_phone_or_email(self, phoneOrEmail):
        phone_email_field = self.wait.until(EC.visibility_of_element_located((By.XPATH, self.loc.get('txt_phoneOrEmail'))))
        phone_email_field.send_keys(phoneOrEmail)

    # Method to click on the "Get OTP" button
     def click_on_btn_get_otp(self):
        get_otp_button = self.wait.until(EC.visibility_of_element_located((By.XPATH, self.loc.get('btn_GetOTP'))))
        get_otp_button.click()

    # Method to enter OTP digits (assumes OTP is a string of numbers)
     def enter_otp(self, otp):
      for i in range(len(otp)):
        # Dynamically generate the XPath for each OTP field
        otp_field_xpath = f"//input[starts-with(@id, 'otp_{i}')]"
        
        # Wait for the OTP field to be visible and interactable
        otp_field = self.wait.until(EC.visibility_of_element_located((By.XPATH, otp_field_xpath)))
        
        # Clear any existing value in the OTP field
        otp_field.clear()
        
        # Enter the current digit from the OTP
        otp_field.send_keys(otp[i])


    # Method to click on the "Login" button after entering OTP
     def click_on_btn_login(self):
        try:
            self.wait.until(EC.invisibility_of_element_located((By.CLASS_NAME, "cdk-overlay-container")))
        except Exception as e:
            print("Overlay or modal still present.")

        login_button = self.wait.until(EC.element_to_be_clickable((By.XPATH, self.loc.get('btn_Login'))))
        login_button.click()
