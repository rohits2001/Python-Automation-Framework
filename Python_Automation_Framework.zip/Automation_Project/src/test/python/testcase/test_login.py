import unittest
import time
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from src.test.python.utilities.ReadXLData import ReadXLData
from src.test.python.pages.test_loginpage import LoginPage
from src.test.python.base.basetest import BaseTest

class TestLogin(BaseTest):
    
    def setUp(self):
        """Set up the test environment."""
        super().setUp()  # Call BaseTest's setUp method to initialize the driver
        self.login = LoginPage(self.driver)
        # Initialize ReadXLData with the path to your Excel file
        self.excel_data = ReadXLData("C:\\Users\\Apptad\\Documents\\Python Scripts\\Automation_Project\\src\\test\\resource\\testData\\testData.xlsx")

    def test_login_with_valid_otp(self):
        """Test login functionality with OTP."""
        # Read test data from the Excel file
        test_data = self.excel_data.get_data(sheet_name="LoginData")

        phoneOrEmail = test_data[0][0]  # Assuming the first column has the email/phone
        otp = test_data[0][1]           # Assuming the second column has the OTP
        expectedURL = test_data[0][2]   # Assuming the third column has the expected URL

        # Perform login with OTP
        self.login.click_on_link_sign_in_using_otp()
        self.login.enter_phone_or_email(phoneOrEmail)
        self.login.click_on_btn_get_otp()
        self.login.enter_otp(otp)
        
        self.login.click_on_btn_login()
       

        # Wait until the page loads and check the current URL
        #WebDriverWait(self.driver, 10).until(EC.url_changes(self.driver.current_url))

        # Assert that the current URL is the expected one
       # self.assertEqual(self.driver.current_url, expectedURL, "URL mismatch after login.")

   


