import os
import datetime
import shutil
from selenium.webdriver.common.by import By
from selenium.webdriver import ActionChains
from test.python.base.basetest import BaseTest

class TakeScreenshot(BaseTest):

    def take_screenshot(self, test_case_name):
        timestamp = datetime.datetime.now().strftime("%Y%m%d%H%M%S")
        file_name = f"{test_case_name}_{timestamp}.png"

        # Access the instance's driver
        screenshot = self.driver.get_screenshot_as_file(os.path.join(".", "screenshot", file_name))
        
        # Copy the screenshot to the desired location
        shutil.copy(screenshot, os.path.join(".", "screenshot", file_name))
