import os
from openpyxl import load_workbook


class ReadXLData:

    def __init__(self, file_path=None):
        """Initialize ReadXLData with an optional file path."""
        # If no file path is provided, use a default path
        self.file_path = file_path or os.path.join(os.getcwd(), "src", "test", "resources", "testData", "testData.xlsx")

    def get_data(self, sheet_name):
        """Get data from the specified Excel sheet."""
        # Load the workbook and the sheet
        wb = load_workbook(self.file_path, data_only=True)
        sheet = wb[sheet_name]

        total_rows = sheet.max_row - 1  # Exclude header row
        total_cols = sheet.max_column

        test_data = []
        for i in range(2, total_rows + 2):  # Start at row 2 to skip header
            row_data = []
            for j in range(1, total_cols + 1):
                cell_value = sheet.cell(row=i, column=j).value
                row_data.append(str(cell_value) if cell_value is not None else "")
            test_data.append(row_data)

        return test_data
