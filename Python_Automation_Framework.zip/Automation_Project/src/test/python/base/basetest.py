import unittest
import time
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.firefox.service import Service as FirefoxService
from selenium.webdriver.edge.service import Service as EdgeService
from selenium.webdriver.safari.service import Service as SafariService
import os
from webdriver_manager.chrome import ChromeDriverManager
from webdriver_manager.firefox import GeckoDriverManager
from webdriver_manager.microsoft import EdgeChromiumDriverManager
import logging
import allure


class BaseTest(unittest.TestCase):

    def setUp(self):
        # Load properties (simulated as environment variables or configuration files)
        self.prop = self.load_properties('config.properties')
        self.loc = self.load_properties('locators.properties')

        # Set up the WebDriver
        browser = self.prop.get("browser").lower()
        if browser == "chrome":
            self.driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()))
        elif browser == "firefox":
            self.driver = webdriver.Firefox(service=FirefoxService(GeckoDriverManager().install()))
        elif browser == "edge":
            self.driver = webdriver.Edge(service=EdgeService(EdgeChromiumDriverManager().install()))
        elif browser == "safari":
            self.driver = webdriver.Safari(service=SafariService())

        self.driver.maximize_window()
        self.driver.get(self.prop.get("testURL"))

        # WebDriverWait
        self.wait = WebDriverWait(self.driver, 20)

        # Create a thread-local variable for assertion messages
        self.assertion_message = None

        # Allure step for initializing the test case
        allure.step("Test setup completed")

    @classmethod
    def tearDownClass(cls):
        # No need to flush reports for Allure
        pass

    def tearDown(self):
        # Close the browser after each test
        self.driver.quit()
        allure.step("Test case executed, browser closed.")

    def load_properties(self, filename):
        """ Simulate loading properties from a file. Can be enhanced to load from real config files. """
        # For the sake of example, load from environment or mock properties.
        properties = {
            "browser": "chrome",
            "testURL": "https://demo.workorbits.com/"
        }
        return properties

    def get_assertion_message(self):
        return self.assertion_message

    def scroll_page_down(self):
        actions = ActionChains(self.driver)
        actions.send_keys(Keys.PAGE_DOWN).perform()
        allure.step("Scrolled down the page")

    def switch_to_new_tab(self):
        original_window = self.driver.current_window_handle
        all_windows = self.driver.window_handles
        for window_handle in all_windows:
            if window_handle != original_window:
                self.driver.switch_to.window(window_handle)
                break
        allure.step("Switched to new browser tab")

    def log_exception_to_report(self, e):
        logging.error(f"Exception occurred: {e}")
        # Log the exception to Allure
        allure.attach(str(e), name="Exception Details", attachment_type=allure.attachment_type.TEXT)
        allure.step(f"Exception occurred: {e}")
        # Log the stack trace
        if e.__traceback__:
            traceback = str(e.__traceback__)
            allure.attach(traceback, name="Stack Trace", attachment_type=allure.attachment_type.TEXT)

    def create_test_report(self, test_login):
        """ Create an Allure report for this test case """
        # Allure automatically generates reports from decorated tests
        allure.dynamic.testcase(test_login)
        allure.dynamic.description("Selenium test execution with Allure reporting.")

    @allure.step("Example of a test step")
    def example_test_step(self):
        # Example test step decorated with Allure step
        pass
