import sys
import os
from unittest import TestResult
from test.python.utilities import TakeScreenshot
from test.python.base.basetest import BaseTest
from allure_pytest import Status
import allure

class Listeners(TakeScreenshot):

    def on_test_start(self, result: TestResult):
        # Create a new test in the extent report
        self.extent_test = self.extent_reports.create_test(result.method_name)

        description = result.description
        if description:
            self.extent_test.log(Status.INFO, f"Test Description: {description}")

    def on_test_success(self, result: TestResult):
        # Log success
        self.extent_test.log(Status.PASS, "Test passed")

    def on_test_failure(self, result: TestResult):
        # Log failure
        self.extent_test.log(Status.FAIL, "Test failed")

        assertion_msg = BaseTest.get_assertion_message()

        # Capture exception details
        throwable = result.throwable
        if isinstance(throwable, AssertionError):
            # Log only the assertion error details
            self.extent_test.log(Status.FAIL, f"Assertion Failed: {assertion_msg}")
        else:
            # Log other exceptions (like Selenium exceptions)
            self.extent_test.log(Status.FAIL, f"Test failed with exception: {throwable}")
            BaseTest.log_exception_to_report(Exception(throwable))

        assertion_msg.remove()

        test_case_name = result.method_name
        try:
            self.take_screenshot(test_case_name)
        except IOError as e:
            print(e)

        assertion_msg.remove()

    def on_test_skipped(self, result: TestResult):
        # Log skipped tests
        self.extent_test.log(Status.SKIP, "Test skipped")
